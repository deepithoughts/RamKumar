package stepDefinitions;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertNotEquals;

import java.util.HashMap;
import java.util.Map;

import io.cucumber.cienvironment.internal.com.eclipsesource.json.JsonObject;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;
import junit.framework.Assert;
import resources.TestBuildData;
import static org.hamcrest.Matchers.*;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThat;

import org.json.JSONObject;


public class AddObjectProgram extends TestBuildData{
	
	RequestSpecification res;
	Response response;
	String response1;
	String id;
	JSONObject requestBody;
	//JsonPath js;
	//JsonObject js;
	ResponseBody body;
	Map<String, String> payload;
	TestBuildData dd = new TestBuildData();
	
	//Post an Object in Rest API
	
	@Given("I hit the url of the Post API Endpoint")
	public void i_hit_the_url_of_the_post_api_endpoint() {
	    RestAssured.baseURI="https://api.restful-api.dev/";
	    res=RestAssured.given();
	   	        
	}

	@When("I pass the url of products in request")
	public void i_pass_the_url_of_products_in_request() {
		
		response =res.header("Content-Type","application/json").log().all()
				.body(dd.AddObjectPayload()).log().all().post("objects");
		System.out.println(response);
		id = response.jsonPath().getString("id");
		System.out.println("Print ID :" + id);
		
		/*Take the id from the response body
		JsonPath js = new JsonPath(String.valueOf(response));
		String id =js.getString("id");
		System.out.println("          ");
		System.out.println("Print ID :" + id);*/
	
		/*Map<String, Object> dataMap = new HashMap<>();
        dataMap.put("year", 2019);
        dataMap.put("price", 1849.99);
        dataMap.put("CPU model", "Intel Core i9");
        dataMap.put("Hard disk size", "1 TB");

        // Create the outer HashMap
        Map<String, Object> productMap = new HashMap<>();
        productMap.put("name", "Apple MacBook Pro 16");
        productMap.put("data", dataMap);    
        res.body(productMap.toString());
        
        response=res.post("objects");
        
        body=response.getBody();
        System.out.println(body.asString()); 
        
        JsonPath js= response.jsonPath();
        String id =js.getString("id");
        System.out.println("Print ID :" + id);*/   
                     
	}

	@Then("I receive response code as {int}")
	public void i_receive_response_code_as(Integer statuscode) {
		int s = response.then().log().all().extract().statusCode();
		assertEquals(s,statuscode);
	}

	//GetSingleObject from Rest API
	
	@Given("I hit the Get single object API")
	public void i_hit_the_get_single_object_api() {
	    RestAssured.baseURI="https://api.restful-api.dev/";
	    res=RestAssured.given();
	    res.given().log().all().header("Content-Type","application/json");
	}

	@When("the user hits the {string} with Get HTTP Request")
	public void the_user_hits_the_with_get_http_request(String endpoint) {
	    
		response =res.when().log().all().get(endpoint);
	}


	@Then("I validate the response code is {int}")
	public void i_validate_the_response_code_is(Integer statuscode) {
	    
		int s = response.then().log().all().extract().statusCode();
		assertEquals(s, statuscode);
		
	}

	@Then("I valide the response body where name is {string}")
	public void i_valide_the_response_body_where_name_is(String actualname) {
		
		String expectedname = response.jsonPath().getString("name");
		assertEquals(expectedname, actualname);
		  
	}
	
	//Get All Objects API
	@Given("I hit the Get all objects API")
	public void i_hit_the_get_all_objects_api() {
	    RestAssured.baseURI="https://api.restful-api.dev/";
	    res=RestAssured.given();
	    res.given().log().all();
	}

	@When("I send a GET request with {string} endpoint")
	public void i_send_a_get_request_with_endpoint(String endpoint) {
		
	    response=res.when().log().all().get(endpoint);
	}

	@Then("the response body should be a non-empty array")
	public void the_response_body_should_be_a_non_empty_array() {
	    response.then().log().all().body("$",is(not(empty())));
	}

	@Then("the response body contains objects with {string},{string},{string} fields")
	public void the_response_body_contains_objects_with_fields(String id, String name, String data) {
	    
        response.then().body("[0]", hasKey("id"));
        response.then().body("[0]", hasKey("name"));
        response.then().body("[0]", hasKey("data"));
        
	}
	
	//Get Single Objects by ID
	@Given("I hit the GET Objects by id")
	public void i_hit_the_get_objects_by_id() {
	    RestAssured.baseURI="https://api.restful-api.dev";
	    res=RestAssured.given();
	    res.given().log().all()
	    .queryParam("id", 3)
	    .queryParam("id", 5)
	    .queryParam("id", 10);
	    
	}

	@When("I send a GET request with endpoint {string} with query parameters {string}")
	public void i_send_a_get_request_with_endpoint_with_query_parameters(String pathparam, String queryparams) {

		response=res.when().log().all().get("/"+pathparam+"?"+queryparams);
				
	}

	@Then("the response code should be {int}")
	public void the_response_code_should_be(Integer code) {
	    response.then().log().all().statusCode(code);
	}

	@Then("the response should contains objects with IDs {string},{string},{string}")
	public void the_response_should_contains_objects_with_i_ds(String id, String name, String data) {
	   response.then().log().all()
	   			.body("id", hasItems(Integer.parseInt(id),(Integer.parseInt(name)),(Integer.parseInt(data))));
	}
	
	
	//Update an Object with ID UserID
	
	@Given("I hit the PUT API endpoint")
	public void i_hit_the_put_api_endpoint() {
	    
		RestAssured.baseURI="https://api.restful-api.dev/";
		//Updating the request body in PUT Request
		
	    requestBody =new JSONObject();
		requestBody.put("name", "Samsung");
		
		JSONObject data=new JSONObject();
		data.put("year", 20199);
        data.put("price", 2049.99);
        data.put("CPU model", "Intel Core i9");
        data.put("Hard disk size", "1 TB");
        data.put("color", "silver");
        
        requestBody.put("data", data);      
	}


	@When("I send a PUT HTTP Request with {string} and payload")
	public void i_send_a_put_http_request_with_and_payload(String endpoint) {
		
		res=RestAssured.given();
		response=res.given()
  	    		.contentType(ContentType.JSON)
  	    		.body(requestBody.toString()).log().all()
  	    		.when().log().all().put(endpoint);
	}

	@Then("the response code received as {int}")
	public void the_response_code_received_as(Integer statuscode) {
	    int s = response.getStatusCode();
	    assertEquals(s, statuscode);
	}

	@Then("the response should contain the object name as {string}")
	public void the_response_should_contain_the_object_name_as(String actualname) {
	    String expectedname=response.jsonPath().getString("name");
	    assertEquals(expectedname,actualname);
	}

	@Then("the response body should contain color as {string}")
	public void the_response_body_should_contain_color_as(String actualColor) {
	    String expectedColor = response.jsonPath().getString("data.\"color\"");
	    assertEquals(expectedColor, actualColor);
	}
	
	//Update an Object with Response Body Validations

		@Given("the API base URL is set")
		public void the_api_base_url_is_set() {
		    RestAssured.baseURI="https://api.restful-api.dev/";
		    res=RestAssured.given();
		}
		
		@When("I send a PUT request to {string} with the following payload")
		public void i_send_a_put_request_to_with_the_following_payload(String endpoint, String payload) {
		   response= res.given().contentType(ContentType.JSON)
				   .body(payload).log().all()
				   .when().put(endpoint);
		    
		}
		
		@Then("the response status code should be {int}")
		public void the_response_status_code_should_be(Integer statuscode) {
			assertEquals(statuscode, response.statusCode());
		    
		}
		
		@Then("the response should contain:")
		public void the_response_should_contain(Map<String, String> expectedFields) {
			for(Map.Entry<String, String> entry : expectedFields.entrySet())
			{
				String jsonpath =entry.getKey();
				String expectedValue= entry.getValue();
				
				Object actualValue=response.jsonPath().get(jsonpath);
				assertNotNull("Expected field missing: " + jsonpath, actualValue);
				assertEquals("Mismatch at field: " + jsonpath, expectedValue, actualValue.toString());
			}
		    
		}
	
		//PatchRequestToupdateName
		@Given("I set the base URL")
		public void i_set_the_base_url() {
		    RestAssured.baseURI="https://api.restful-api.dev/";	
		    res=RestAssured.given();
		}

		@Given("I have valid patch Payload")
		public void i_have_valid_patch_payload() {
			
			payload=new HashMap();
			payload.put("name", "Vivo 23e (Updated Name)");
		}

		@When("I send Patch request to update the object with endpoint {string}")
		public void i_send_patch_request_to_update_the_object_with_endpoint(String endpoint) {
		    response=res.given()
		    		.contentType(ContentType.JSON)
		    		.body(payload)
		    		.when().log().all().patch(endpoint);
		}

		@Then("the response status code is {int}")
		public void the_response_status_code_is(Integer expectedStatusCode) {
			//assertEquals(response.getStatusCode(), is(expectedStatusCode));
			res.then().log().all().expect().statusCode(200);
		}

		@Then("the response should contain the updated name")
		public void the_response_should_contain_the_updated_name() {
		    String updatedname=response.jsonPath().getString("name");
		    assertEquals(updatedname, equalTo("Vivo 23e (Updated Name)"));
		    res.then().log().all();
		}
	
		//Deleting an Object
		@Given("I have the base url")
		public void i_have_the_base_url() {
		    RestAssured.baseURI="https://api.restful-api.dev/";
		    res=RestAssured.given();
		}

		@When("I send delete request with endpoint {string}")
		public void i_send_delete_request_with_endpoint(String endpoint) {
		    response=res.given().log().all()
		    		.when().delete(endpoint);
		}

		@Then("the response should confirm deletion")
		public void the_response_should_confirm_deletion() {
		    String actualMessage=response.jsonPath().getString("message");
		    assertEquals(actualMessage.toLowerCase(),containsString("deleted"));
		}

}




