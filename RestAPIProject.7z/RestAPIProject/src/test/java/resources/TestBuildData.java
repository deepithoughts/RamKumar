package resources;

import payload.Data;
import payload.Product;

public class TestBuildData {
	
	//This data is for POST Object
	public Product AddObjectPayload()
	{
		Data d= new Data();
		d.setCPUmodel("Intel Core i9");
		d.setHarddisksize("1 TB");
		d.setPrice(1849.99);
		d.setYear(2019);
		
		Product p = new Product();
		p.setData(d);
		p.setName("Apple MacBook Pro 16");
		
		return p;
		
	}
	
	
	

}
