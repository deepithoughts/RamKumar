package payload;

public class Data {
	
	//Create a pojo class for data
	/* {
   "name": "Apple MacBook Pro 16",
   "data": {
      "year": 2019,
      "price": 1849.99,
      "CPU model": "Intel Core i9",
      "Hard disk size": "1 TB"
   }
}*/
	
	private int year;
	private double price;
	private String CPUmodel;
	private String Harddisksize;
	
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public String getCPUmodel() {
		return CPUmodel;
	}
	public void setCPUmodel(String cPUmodel) {
		CPUmodel = cPUmodel;
	}
	public String getHarddisksize() {
		return Harddisksize;
	}
	public void setHarddisksize(String harddisksize) {
		Harddisksize = harddisksize;
	}
	

}
